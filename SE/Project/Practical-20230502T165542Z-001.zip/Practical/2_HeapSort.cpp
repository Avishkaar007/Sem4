#include <iostream>
#include <vector>

using namespace std;

int heapify(vector<int> &arr, int n, int i, int &comparisons) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest]) {
        largest = left;
    }

    if (right < n && arr[right] > arr[largest]) {
        largest = right;
    }

    if (largest != i) {
        swap(arr[i], arr[largest]);
        comparisons++;
        comparisons += heapify(arr, n, largest, comparisons);
    }

    return comparisons;
}

int heap_sort(vector<int> &arr, int &comparisons) {
    int n = arr.size();

    for (int i = n / 2 - 1; i >= 0; i--) {
        comparisons += heapify(arr, n, i, comparisons);
    }

    for (int i = n - 1; i > 0; i--) {
        swap(arr[0], arr[i]);
        comparisons++;
        comparisons += heapify(arr, i, 0, comparisons);
    }

    return comparisons;
}

int main() {
    vector<int> arr = {9, 8, 7, 6, 5, 4, 3, 2, 1};
    int comparisons = 0;
    comparisons = heap_sort(arr, comparisons);
    for (int i = 0; i < arr.size(); i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
    cout << "Number of comparisons: " << comparisons << endl;
    return 0;
}
