#include <iostream>
#include <queue>
#include <vector>

using namespace std;

// Function to perform Breadth-First Search in a graph
void bfs(vector<vector<int>> &adjList, int startNode) {
    vector<bool> visited(adjList.size(), false);
    queue<int> q;

    visited[startNode] = true;
    q.push(startNode);

    while (!q.empty()) {
        int currNode = q.front();
        q.pop();
        cout << currNode << " ";

        for (int i = 0; i < adjList[currNode].size(); i++) {
            int neighbor = adjList[currNode][i];
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                q.push(neighbor);
            }
        }
    }
}

int main() {
    // Example graph represented using adjacency list
    vector<vector<int>> adjList = {{1, 2}, {0, 2, 3, 4}, {0, 1, 3}, {1, 2, 4}, {1, 3}};

    cout << "BFS starting from node 0: ";
    bfs(adjList, 0);
    cout << endl;

    cout << "BFS starting from node 3: ";
    bfs(adjList, 3);
    cout << endl;

    return 0;
}
  