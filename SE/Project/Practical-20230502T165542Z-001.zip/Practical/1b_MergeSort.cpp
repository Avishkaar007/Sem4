#include <iostream>
#include <vector>

using namespace std;

int merge(vector<int> &arr, int left, int mid, int right) {
    int comparisons = 0;

    int n1 = mid - left + 1;
    int n2 = right - mid;

    vector<int> left_half(n1);
    vector<int> right_half(n2);

    for (int i = 0; i < n1; i++) {
        left_half[i] = arr[left + i];
    }
    for (int j = 0; j < n2; j++) {
        right_half[j] = arr[mid + 1 + j];
    }

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (left_half[i] <= right_half[j]) {
            arr[k] = left_half[i];
            i++;
        } else {
            arr[k] = right_half[j];
            j++;
        }
        k++;
        comparisons++;
    }

    while (i < n1) {
        arr[k] = left_half[i];
        i++;
        k++;
    }

    while (j < n2) {
        arr[k] = right_half[j];
        j++;
        k++;
    }

    return comparisons;
}

int merge_sort(vector<int> &arr, int left, int right) {
    int comparisons = 0;
    if (left < right) {
        int mid = left + (right - left) / 2;
        comparisons += merge_sort(arr, left, mid);
        comparisons += merge_sort(arr, mid + 1, right);
        comparisons += merge(arr, left, mid, right);
    }
    return comparisons;
}

int main() {
    vector<int> arr = {5, 2, 1, 9, 0, 4, 6};
    int comparisons = merge_sort(arr, 0, arr.size() - 1);
    for (int i = 0; i < arr.size(); i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
    cout << "Number of comparisons: " << comparisons << endl;
    return 0;
}
