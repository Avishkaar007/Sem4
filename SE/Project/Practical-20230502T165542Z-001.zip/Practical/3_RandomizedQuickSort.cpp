#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <algorithm>

using namespace std;

int partition(vector<int> &arr, int low, int high, int &comparisons) {
    int pivot = arr[high];
    int i = low - 1;

    for (int j = low; j < high; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(arr[i], arr[j]);
            comparisons++;
        }
    }

    swap(arr[i + 1], arr[high]);
    comparisons++;

    return i + 1;
}

int randomized_partition(vector<int> &arr, int low, int high, int &comparisons) {
    random_device rd;
    mt19937 rng(rd());
    uniform_int_distribution<int> uni(low, high);

    int pivot_index = uni(rng);
    swap(arr[high], arr[pivot_index]);
    comparisons++;

    return partition(arr, low, high, comparisons);
}

int randomized_quick_sort(vector<int> &arr, int low, int high, int &comparisons) {
    if (low < high) {
        int p = randomized_partition(arr, low, high, comparisons);
        randomized_quick_sort(arr, low, p - 1, comparisons);
        randomized_quick_sort(arr, p + 1, high, comparisons);
    }

    return comparisons;
}

int main() {
    random_device rd;
    mt19937 rng(rd());
    uniform_int_distribution<int> uni(1, 1000);

    vector<int> arr;
    for (int i = 0; i < 20; i++) {
        arr.push_back(uni(rng));
    }

    cout << "Input Array: ";
    for (int i = 0; i < arr.size(); i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    int count = 0;
    randomized_quick_sort(arr, 0, arr.size() - 1, count);

    cout << "Sorted Array: ";
    for (int i = 0; i < arr.size(); i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    cout << "Number of comparisons: " << count << endl;

    return 0;
}
