#include <iostream>
#include <vector>
#include <stack>

using namespace std;

// Function to perform Depth-First Search in a graph
void dfs(vector<vector<int>> &adjList, int startNode) {
    vector<bool> visited(adjList.size(), false);
    stack<int> s;

    s.push(startNode);

    while (!s.empty()) {
        int currNode = s.top();
        s.pop();

        if (!visited[currNode]) {
            visited[currNode] = true;
            cout << currNode << " ";

            for (int i = adjList[currNode].size() - 1; i >= 0; i--) {
                int neighbor = adjList[currNode][i];
                if (!visited[neighbor]) {
                    s.push(neighbor);
                }
            }
        }
    }
}

int main() {
    // Example graph represented using adjacency list
    vector<vector<int>> adjList = {{1, 2}, {0, 2, 3, 4}, {0, 1, 3}, {1, 2, 4}, {1, 3}};

    cout << "DFS starting from node 0: ";
    dfs(adjList, 0);
    cout << endl;

    cout << "DFS starting from node 3: ";
    dfs(adjList, 3);
    cout << endl;

    return 0;
}
